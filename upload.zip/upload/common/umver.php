<?php

define('UniMatrix', 'https://www.mlmscript.net');

// base version
$umbasever = '2.3.0';
$umisverin = 1;
$umisverup = 0;
$umverttel = '';
